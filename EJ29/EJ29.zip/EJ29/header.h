#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

void calcular (float,float,float);
void ordenar (float,float,float);
void numerar (float,float,float);
void serie (float,float,float);
#endif
