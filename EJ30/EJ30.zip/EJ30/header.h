#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#define SI 1
#define NO 0
#define MAX 100
#include <stdio.h>
#include <stdlib.h>

int vocal (char[]);
void contar (char[]);
void palabras (char[]);

#endif
